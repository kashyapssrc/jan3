package com.objectfrontier.training.spring.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.spring.model.Person;
import com.objectfrontier.training.spring.service.PersonService;
import com.objectfrontier.training.spring.util.BeanManager;
import com.objectfrontier.training.spring.util.ConnectionManager;
import com.objectfrontier.training.spring.util.JsonConverter;

@WebServlet
public class PersonServlet extends HttpServlet {

    private static final long serialVersionUID = -1741056946109290187L;

    boolean flag;
    PersonService personService = BeanManager.getBean(PersonService.class);

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response) throws IOException, ServletException {

        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        String personId = request.getParameter("id");
        String includeAddress = request.getParameter("addr");
        Connection connection = ConnectionManager.connectionThread.get();

        if (personId != null) {

            Person person = personService.read(connection,
                                               Long.parseLong(personId),
                                               Boolean.parseBoolean(includeAddress));
//            out.write(JsonConverter.toJson(person));
        } else {
            List<Person> personList = personService.readAll(connection);
            StringBuilder personTable = new StringBuilder();
            for(Person everyPerson : personList) {

                personTable.append("<tr>")
                           .append("<td>")
                           .append(everyPerson.getId())
                           .append("</td>")
                           .append("<td>")
                           .append(everyPerson.getFirstName())
                           .append("</td>")
                           .append("<td>")
                           .append(everyPerson.getLastName())
                           .append("</td>")
                           .append("<td>")
                           .append(everyPerson.getEmail())
                           .append("</td>")
                           .append("<td>")
                           .append(everyPerson.getBirth_date())
                           .append("</td>")
                           .append("</tr>");
            }
            out.write(personTable.toString());
//            out.write(JsonConverter.toJson(allPersons));
//            request.setAttribute("personList", personList);
//            request.getRequestDispatcher("/html/personTable.jsp")
//                   .forward(request, response);
        }
        out.close();
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {

        PrintWriter out = response.getWriter();
        response.setContentType("application/json");

        Connection connection = ConnectionManager.connectionThread.get();

        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines()
                                       .collect(Collectors.toList());

        String personJson = String.join("", jsonLines);
        String.format("INPUT JSON >> %s", personJson);

        Person input = JsonConverter.toObject(personJson, Person.class);
        Person person = personService.create(connection, input);
//        out.write(JsonConverter.toJson(person));
        out.close();
    }

    @Override
    protected void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException {


        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        String operation = request.getParameter("op");
        Connection connection = ConnectionManager.connectionThread.get();

        if (operation.equals("update")) {

            BufferedReader reader = request.getReader();
            List<String> jsonLines = reader.lines()
                                           .collect(Collectors.toList());

            String personJson = String.join("", jsonLines);
            System.out.format("Input JSON >> %s", personJson);

            Person input = JsonConverter.toObject(personJson, Person.class);
            Person person = personService.update(connection, input);
            out.write(JsonConverter.toJson(person));

        } else if (operation.equals("delete")) {

            BufferedReader reader = request.getReader();
            List<String> jsonLines = reader.lines()
                                           .collect(Collectors.toList());

            String personJson = String.join("", jsonLines);
            System.out.format("Input JSON >> %s", personJson);

            Person input = JsonConverter.toObject(personJson, Person.class);
            personService.delete(connection, input);
        }
        out.close();
    }
}
