package com.objectfrontier.training.spring.util;

public interface Constant {

    String ID = "id";
    String ADDRESS_ID = "address_id";
    String FIRST_NAME = "firstname";
    String LAST_NAME = "lastname";
    String EMAIL = "email";
    String BIRTH_DATE = "birth_date";
    String PASSWORD = "password";
    String IS_ADMIN = "isAdmin";
    String STREET = "street";
    String CITY = "city";
    String POSTAL_CODE = "postal_code";
}
