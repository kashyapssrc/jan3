package com.objectfrontier.training.spring.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;

import com.objectfrontier.training.spring.model.Address;
import com.objectfrontier.training.spring.service.AddressService;
import com.objectfrontier.training.spring.util.AppException;
import com.objectfrontier.training.spring.util.BeanManager;
import com.objectfrontier.training.spring.util.ConnectionManager;
import com.objectfrontier.training.spring.util.JsonConverter;

public class AddressServlet extends HttpServlet {

    /**
     *
     */
    private static final long serialVersionUID = 6226217839650875450L;

    boolean flag;
    AddressService addressService = BeanManager.getBean(AddressService.class);

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        String addressId = request.getParameter("id");
        String operation = request.getParameter("op");
        String[] fieldName = request.getParameterValues("in");
        String searchText = request.getParameter("search");

        Connection connection = ConnectionManager.connectionThread.get();

        try {
            if (operation.equals("read")) {

                Address address = addressService.read(connection ,Long.parseLong(addressId));
                response.setStatus(HttpStatus.SC_OK);
                out.format("%s", JsonConverter.toJson(address));
                flag = true;
            } else if (operation.equals("readAll")) {

                List<Address> allPerson = addressService.readAll(connection);
                response.setStatus(HttpStatus.SC_OK);
                out.format("%s", JsonConverter.toJson(allPerson));
                flag = true;
            } else if (operation.equals("search")) {

                List<Address> searchResult = addressService.search(connection, fieldName, searchText);
                response.setStatus(HttpStatus.SC_OK);
                out.format("%s", JsonConverter.toJson(searchResult));
                flag = true;
            }
        } catch (AppException e) {
            out.write(JsonConverter.toJson(e.getErrorList()));
            response.setStatus(HttpStatus.SC_INTERNAL_SERVER_ERROR);
            flag = false;
        }

        out.close();
    }

    @Override
    protected void doPut (HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();


        Connection connection = ConnectionManager.connectionThread.get();
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines()
                                       .collect(Collectors.toList());

        String addressJson = String.join("", jsonLines);
        System.out.format("Input JSON >> %s", addressJson);

        Address input = JsonConverter.toObject(addressJson, Address.class);
        Address address = null;
        try {
            address = addressService.create(connection ,input);
            response.setStatus(HttpStatus.SC_OK);
            out.format("%s", JsonConverter.toJson(address));
            flag = true;
        } catch (AppException e) {
            out.write(JsonConverter.toJson(e.getErrorList()));
            response.setStatus(HttpStatus.SC_INTERNAL_SERVER_ERROR);
            flag = false;
        }
        out.close();
    }

    @Override
    protected void doPost (HttpServletRequest request, HttpServletResponse response) throws IOException {


        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        String addressId = request.getParameter("aid");
        Connection connection = ConnectionManager.connectionThread.get();

        if (Objects.isNull(addressId)) {

            BufferedReader reader = request.getReader();

            List<String> jsonLines = reader.lines()
                                           .collect(Collectors.toList());

            String addressJson = String.join("", jsonLines);
            System.out.format("\nInput JSON >> %s", addressJson);

            Address input = JsonConverter.toObject(addressJson, Address.class);
            Address address;
            try {
                address = addressService.update(connection, input);
                response.setStatus(HttpStatus.SC_OK);
                out.format("%s", JsonConverter.toJson(address));
                flag = true;
            } catch (AppException e) {
                out.write(JsonConverter.toJson(e.getErrorList()));
                response.setStatus(HttpStatus.SC_INTERNAL_SERVER_ERROR);
                flag = false;
            }
        } else {

            try {
                addressService.delete(connection ,Long.parseLong(addressId));
                response.setStatus(HttpStatus.SC_OK);
                flag = true;
            } catch (AppException e) {
                out.write(JsonConverter.toJson(e.getErrorList()));
                response.setStatus(HttpStatus.SC_INTERNAL_SERVER_ERROR);
                flag = false;
            }
        }
        out.close();
    }
}
