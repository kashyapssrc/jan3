package com.objectfrontier.training.spring.controller;

import java.sql.Connection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.objectfrontier.training.spring.model.Person;
import com.objectfrontier.training.spring.service.PersonService;
import com.objectfrontier.training.spring.util.ConnectionManager;

@Controller
public class PersonController {

    @Autowired
    PersonService personService;

    @GetMapping("/do/person")
    public ResponseEntity<List<Person>> readAll() {

        ConnectionManager.setConnection();
        Connection connection = ConnectionManager.connectionThread.get();
        List<Person> personList = personService.readAll(connection);
        return ResponseEntity.ok()
                             .body(personList);
    }

    @GetMapping("/do/person/{id}/{includeAddress}")
    public ResponseEntity<Person> read(@PathVariable("id") long id,
                                       @PathVariable("includeAddress") boolean includeAddress) {

        ConnectionManager.setConnection();
        Connection connection = ConnectionManager.connectionThread.get();
        Person person = personService.read(connection, id, includeAddress);
        return ResponseEntity.ok()
                             .body(person);
    }

    @PutMapping("/do/person")
    public ResponseEntity<Person> create(@RequestBody Person person) {

        ConnectionManager.setConnection();
        Connection connection = ConnectionManager.connectionThread.get();
        Person createdPerson = personService.create(connection, person);
        return ResponseEntity.ok().body(createdPerson);
    }

    @PostMapping("/do/person/update")
    public ResponseEntity<Person> update(@RequestBody Person person){

        ConnectionManager.setConnection();
        Connection connection = ConnectionManager.connectionThread.get();
        Person updatedPerson = personService.update(connection, person);
        return ResponseEntity.ok()
                             .body(updatedPerson);
    }

    @PostMapping("/do/person/delete")
    public void delete(@RequestBody Person person){

        ConnectionManager.setConnection();
        Connection connection = ConnectionManager.connectionThread.get();
        personService.delete(connection, person);
    }

}
