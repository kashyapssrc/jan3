package com.objectfrontier.training.hibernateconfig.controller;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.objectfrontier.training.hibernateconfig.model.Person;
import com.objectfrontier.training.hibernateconfig.service.PersonService;

@RestController
public class PersonController {

    @Autowired
    PersonService personService;

    @GetMapping("/person")
    public String readAll() {

        SessionFactory factory = new Configuration().configure("hibernate-cfg.xml")
                                                    .addResource("hibernateMapping.xml")
                                                    .buildSessionFactory();
        Session session = factory.getCurrentSession();
        List<Person> personList = personService.readAll(session);
        session.getTransaction()
        .commit();
        session.close();
        factory.close();
        return personList.toString();
    }

    @GetMapping("/person/read")
    public String read() {

        SessionFactory factory = new Configuration().configure("hibernate-cfg.xml")
                                                    .addResource("hibernateMapping.xml")
                                                    .buildSessionFactory();
        Session session = factory.getCurrentSession();
        Person person = personService.read(session, 2);
        session.getTransaction()
               .commit();
        session.close();
        factory.close();
        return person.toString();
    }

}
