package com.objectfrontier.training.hibernateconfig.service;

import java.util.List;

import org.hibernate.Session;
import org.springframework.stereotype.Service;

import com.objectfrontier.training.hibernateconfig.model.Person;

@Service
public class PersonService {

    public List<Person> readAll(Session session) {

        session.beginTransaction();
        List<Person> personList = session.createQuery("from Person")
                                         .getResultList();
        return personList;
    }

    public Person read(Session session,long id) {

        session.beginTransaction();
        Person person = session.get(Person.class, id);
        return person;
    }
}

