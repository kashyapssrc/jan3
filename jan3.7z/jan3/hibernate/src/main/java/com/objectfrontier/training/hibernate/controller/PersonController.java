package com.objectfrontier.training.hibernate.controller;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.objectfrontier.training.hibernate.model.Person;
import com.objectfrontier.training.hibernate.service.PersonService;

@RestController
public class PersonController {

    @Autowired
    PersonService personService;

    @GetMapping("/person")
    public String readAll() {

        SessionFactory factory = new Configuration().configure("hibernate-cfg.xml")
                                                    .addAnnotatedClass(Person.class)
                                                    .buildSessionFactory();
        Session session = factory.getCurrentSession();
        List<Person> personList = personService.readAll(session);
        session.getTransaction()
               .commit();
        session.close();
        factory.close();
        return personList.toString();
    }

    @PutMapping("create")
    public long create() {

        SessionFactory factory = new Configuration().configure("hibernate-cfg.xml")
                                                    .addAnnotatedClass(Person.class)
                                                    .buildSessionFactory();
        Session session = factory.getCurrentSession();
        Person person = new Person("stephen",
                                   "strange",
                                   "stephenstrange@time.com",
                                   "17-07-1777",
                                   "shamballa",
                                   true,
                                   null);
        long personId = personService.create(session, person);
        session.getTransaction()
               .commit();
        session.close();
        factory.close();
        return personId;
    }
}
