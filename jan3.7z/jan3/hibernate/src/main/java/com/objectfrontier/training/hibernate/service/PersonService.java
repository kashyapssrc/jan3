package com.objectfrontier.training.hibernate.service;

import java.util.List;

import org.hibernate.Session;
import org.springframework.stereotype.Service;

import com.objectfrontier.training.hibernate.model.Person;

@Service
public class PersonService {

    public List<Person> readAll(Session session) {

        session.beginTransaction();
        List<Person> personList = session.createQuery("from person").getResultList();
        return personList;

    }

    public Long create(Session session, Person person) {
        session.beginTransaction();
        session.save(person);
        long id = person.getId();
        return id;
    }
}
