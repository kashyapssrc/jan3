package com.objectfrontier.training.rest.service;

import static com.objectfrontier.training.rest.util.Constant.CITY;
import static com.objectfrontier.training.rest.util.Constant.ID;
import static com.objectfrontier.training.rest.util.Constant.POSTAL_CODE;
import static com.objectfrontier.training.rest.util.Constant.STREET;
import static com.objectfrontier.training.rest.util.Statement.CREATE_ADDRESS;
import static com.objectfrontier.training.rest.util.Statement.DELETE_ADDRESS;
import static com.objectfrontier.training.rest.util.Statement.READ_ADDRESS;
import static com.objectfrontier.training.rest.util.Statement.READ_ALL_ADDRESS;
import static com.objectfrontier.training.rest.util.Statement.UPDATE_ADDRESS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.stereotype.Service;

import com.objectfrontier.training.rest.model.Address;
import com.objectfrontier.training.rest.util.AppException;
import com.objectfrontier.training.rest.util.ErrorCodes;

@Service
public class AddressService {

    public AddressService() {
        super();
    }

    private boolean isEmpty(String param) {

        if (Objects.nonNull(param)) {
            return "".equals(param.trim());
        }
        return true;
    }

    private void isValid(Address address) {

        List<ErrorCodes> errorList = new ArrayList<>();
        if(isEmpty(address.getStreet()))  { errorList.add(ErrorCodes.STREET_NULL); }
        if(isEmpty(address.getCity()))    { errorList.add(ErrorCodes.CITY_NULL); }
        if(address.getPostal_code() == 0) { errorList.add(ErrorCodes.POSTAL_CODE_NULL); }

        if(!errorList.isEmpty()) {
            throw new AppException(errorList);
        }
    }

    private Address constructAddress(ResultSet resultSet) {

        try {
            Address address = new Address();
            address.setId(resultSet.getLong(ID));
            address.setStreet(resultSet.getString(STREET));
            address.setCity(resultSet.getString(CITY));
            address.setPostal_code(resultSet.getInt(POSTAL_CODE));
            return address;
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR, e.getCause());
        }
    }

    public Address create(Connection connection, Address address) {

        log("%s", "create address method begins ");
        isValid(address);
        try {
            PreparedStatement createStatement = connection.prepareStatement(CREATE_ADDRESS,
                                                                   Statement.RETURN_GENERATED_KEYS);
            createStatement.setString(1, address.getStreet());
            createStatement.setString(2, address.getCity());
            createStatement.setInt(3, address.getPostal_code());
            createStatement.execute();

            ResultSet resultSet = createStatement.getGeneratedKeys();
            resultSet.next();

            address.setId(resultSet.getLong(1));
            log("%s", "create method ends ");
            return address;
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }
    }

    public Address update(Connection connection,Address address) {

        log("%s", "update address method begins ");
        isValid(address);
        try {
            PreparedStatement updateStatement = connection.prepareStatement(UPDATE_ADDRESS);
            updateStatement.setString(1, address.getStreet());
            updateStatement.setString(2, address.getCity());
            updateStatement.setInt(3, address.getPostal_code());
            updateStatement.setLong(4, address.getId());

            int affectedRows = updateStatement.executeUpdate();
            if (affectedRows == 0) {
                throw new AppException(ErrorCodes.ID_NOT_FOUND);
            }
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }
        log("%s", "update address method ends ");
        return address;
    }

    public Address read(Connection connection, long addressId) {

        log("%s", "read address method begins ");
        Address address;
        try {
            PreparedStatement readStatement = connection.prepareStatement(READ_ADDRESS);
            readStatement.setLong(1, addressId);

            ResultSet resultSet = readStatement.executeQuery();
            if (resultSet.next()) {
                address = constructAddress(resultSet);
            } else {
                throw new AppException(ErrorCodes.ID_NOT_FOUND);
            }
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }

        log("%s", "read address method ends");
        return address;
    }

    public List<Address> readAll(Connection connection) {

        log("%s", "readAll address method begins ");
        List<Address> addressList;
        try {
            ResultSet resultSet = connection.createStatement()
                                          .executeQuery(READ_ALL_ADDRESS);

            addressList = new ArrayList<>();
            while (resultSet.next()) {
                Address address = constructAddress(resultSet);
                addressList.add(address);
            }
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR, e.getCause());
        }
        log("%s", "readAll address method ends");
        return addressList;
    }

    public void delete(Connection connection, long addressId) {

        log("%s", "delete address method begins ");
        try {
            PreparedStatement deleteStatement = connection.prepareStatement(DELETE_ADDRESS);
            deleteStatement.setLong(1, addressId);
            int rowsAffected = deleteStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new AppException(ErrorCodes.ID_NOT_FOUND);
            }
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR, e.getCause());
        }
        log("%s", "delete address method ends ");
    }

    public List<Address> search(Connection connection, String[] fieldName, String searchText) {

        log("%s", "search address method begins ");
        List<ErrorCodes> errorList = new ArrayList<>();

        StringBuilder statement = new StringBuilder()
                .append("SELECT id           ")
                .append("     , street       ")
                .append("     , city         ")
                .append("     , postal_code  ")
                .append("  FROM f_address      ")
                .append(" WHERE              ");

        for (int i = 0; i <= fieldName.length - 1; i++) {

            String dbColumn = null;
            switch(fieldName[i]) {

            case "street" :
                dbColumn = "street";
                break;

            case "city" :
                dbColumn = "city";
                break;

            case "postalCode" :
                dbColumn = "postal_code";
                break;

            default :
                errorList.add(ErrorCodes.FIELD_NULL);
            }

            if(i == 0) {
                statement.append(dbColumn   );
                statement.append(" LIKE ?   ");
            } else {
                statement.append("OR " + dbColumn   );
                statement.append(" LIKE ?           ");
            }
        }

        if(searchText == null) { errorList.add(ErrorCodes.SEARCH_TEXT_EMPTY); }
        List<Address> addressList = new ArrayList<>();
        try {
            PreparedStatement searchStatement = connection.prepareStatement(statement.toString());
            for(int i = 1; i <= fieldName.length ; i++ ) {
                searchStatement.setString(i, searchText + "%" );
            }

            ResultSet resultSet = searchStatement.executeQuery();
            while(resultSet.next()) {
                Address address = constructAddress(resultSet);
                addressList.add(address);
            }
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }

        if(!errorList.isEmpty()) { throw new AppException(errorList); }
        log("%s", "search address method ends ");
        return addressList;
    }

    public static void log(String format,Object args) {
        System.out.format(format, args);
    }

}
