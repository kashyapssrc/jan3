package com.objectfrontier.training.rest.util;

public interface Statement {

    String VALIDATE_AUTO_INCREMENT = new StringBuilder()
            .append("SELECT id       ")
            .append("  FROM f_person ")
            .toString();

    String VALIDATE_DUPLICATE_EMAIL = new StringBuilder()
            .append("SELECT email                           ")
            .append("  FROM f_person                        ")
            .append(" WHERE email = ?                       ")
            .toString();

    String VALIDATE_DUPLICATE_NAME = new StringBuilder()
            .append("SELECT firstname                       ")
            .append("     , lastname                        ")
            .append("  FROM f_person                        ")
            .append(" WHERE firstname = ? AND lastname = ?  ")
            .toString();

    String TRUNCATE_PERSON = "TRUNCATE TABLE f_person ";

    String DELETE_ALL_ADDRESS = new StringBuilder()
            .append(" DELETE FROM f_address ")
            .toString();

    String RESET_ADDRESS_AUTO_INCREMENT = new StringBuilder()
            .append("ALTER TABLE f_address ")
            .append("AUTO_INCREMENT = 1    ")
            .toString();

    String CREATE_ADDRESS = new StringBuilder()
            .append("INSERT INTO f_address (street      ")
            .append("                    , city         ")
            .append("                    , postal_code) ")
            .append("VALUES (?,?,?)                     ")
            .toString();

    String UPDATE_ADDRESS = new StringBuilder()
            .append("UPDATE f_address         ")
            .append("   SET street = ?        ")
            .append("     , city = ?          ")
            .append("     , postal_code = ?   ")
            .append(" WHERE id = ?            ")
            .toString();

    String READ_ADDRESS = new StringBuilder()
            .append("SELECT id           ")
            .append("     , street       ")
            .append("     , city         ")
            .append("     , postal_code  ")
            .append("  FROM f_address    ")
            .append(" WHERE id = ?       ")
            .toString();

    String READ_ALL_ADDRESS = new StringBuilder()
            .append("SELECT  id          ")
            .append("      , street      ")
            .append("      , city        ")
            .append("      , postal_code ")
            .append("  FROM f_address    ")
            .toString();

    String DELETE_ADDRESS = new StringBuilder()
            .append("DELETE           ")
            .append("  FROM f_address ")
            .append(" WHERE id = ?    ")
            .toString();

    String CREATE_PERSON = new StringBuilder()
            .append("INSERT INTO f_person (firstname    ")
            .append("                   , lastname      ")
            .append("                   , email         ")
            .append("                   , birth_date    ")
            .append("                   , created_date  ")
            .append("                   , password      ")
            .append("                   , isAdmin)      ")
            .append("VALUES (?,?,?,?,?,?,?)           ")
            .toString();

    String UPDATE_PERSON = new StringBuilder()
            .append("UPDATE f_person       ")
            .append("   SET firstname = ?  ")
            .append("     , lastname = ?   ")
            .append("     , email = ?      ")
            .append("     , birth_date = ? ")
            .append("     , password = ?   ")
            .append("     , isAdmin = ?    ")
            .append(" WHERE id = ?         ")
            .toString();

    String READ_PERSON = new StringBuilder()
            .append("SELECT id           ")
            .append("     , firstname    ")
            .append("     , lastname     ")
            .append("     , email        ")
            .append("     , address_id   ")
            .append("     , birth_date   ")
            .append("     , created_date ")
            .append("     , password     ")
            .append("     , isAdmin      ")
            .append("  FROM f_person     ")
            .append(" WHERE id = ?       ")
            .toString();

    String READ_ALL_PERSON = new StringBuilder()
            .append(" SELECT id           ")
            .append("      , firstname    ")
            .append("      , lastname     ")
            .append("      , address_id   ")
            .append("      , email        ")
            .append("      , birth_date   ")
            .append("      , created_date ")
            .append("      , password     ")
            .append("      , isAdmin      ")
            .append("  FROM f_person      ")
            .toString();

    String DELETE_PERSON = new StringBuilder()
            .append("DELETE          ")
            .append("  FROM f_person ")
            .append(" WHERE id = ?   ")
            .toString();

    String VALIDATE_CREDENTIALS = new StringBuilder()
            .append("SELECT email                      ")
            .append("     , password                   ")
            .append("     , isAdmin                    ")
            .append("  FROM f_person                   ")
            .append(" WHERE email = ? AND password = ? ")
            .toString();
}
