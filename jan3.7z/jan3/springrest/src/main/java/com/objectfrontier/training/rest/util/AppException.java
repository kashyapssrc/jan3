package com.objectfrontier.training.rest.util;

import java.util.ArrayList;
import java.util.List;

public class AppException extends RuntimeException{

    private static final long serialVersionUID = -4535673690222114178L;

    private List<ErrorCodes> errorList;

    public AppException(ErrorCodes code, Throwable cause) {

        super(cause);
        this.errorList= new ArrayList<>();
        errorList.add(code);
    }

    public AppException(ErrorCodes code) {

        super();
        this.errorList= new ArrayList<>();
        errorList.add(code);
    }

    public AppException(List<ErrorCodes> errorList) {

        super();
        this.errorList = errorList;
    }

    public List<ErrorCodes> getErrorList() {
        return errorList;
    }
}
