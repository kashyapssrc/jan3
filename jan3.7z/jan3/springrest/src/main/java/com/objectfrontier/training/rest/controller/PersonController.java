package com.objectfrontier.training.rest.controller;

import java.sql.Connection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.objectfrontier.training.rest.model.Person;
import com.objectfrontier.training.rest.service.PersonService;
import com.objectfrontier.training.rest.util.ConnectionManager;

@Controller
public class PersonController {

    @Autowired
    PersonService personService;

    @GetMapping("/jspdemo")
    public String readAllJsp(ModelMap model) {

        ConnectionManager.setConnection();
        Connection connection = ConnectionManager.connectionThread.get();
        List<Person> personList = personService.readAll(connection);
        System.out.println(personList);
        model.addAttribute("personList", personList);
        ConnectionManager.manageTransaction(connection, true);
        return "index";
    }

    @GetMapping("/person")
    public List<Person> readAll() {

        ConnectionManager.setConnection();
        Connection connection = ConnectionManager.connectionThread.get();
        List<Person> personList = personService.readAll(connection);
        ConnectionManager.manageTransaction(connection, true);
        return personList;
    }

    @GetMapping("/person/{id}/{includeAddress}")
    public Person read(@PathVariable("id") long id,
                       @PathVariable("includeAddress") boolean includeAddress) {

        ConnectionManager.setConnection();
        Connection connection = ConnectionManager.connectionThread.get();
        Person person = personService.read(connection, id, includeAddress);
        ConnectionManager.manageTransaction(connection, true);
        return person;
    }

    @PutMapping("/person")
    public Person create(@RequestBody Person person) {

        ConnectionManager.setConnection();
        Connection connection = ConnectionManager.connectionThread.get();
        Person createdPerson = personService.create(connection, person);
        return createdPerson;
    }

    @PostMapping("/person/update")
    public Person update(@RequestBody Person person){

        ConnectionManager.setConnection();
        Connection connection = ConnectionManager.connectionThread.get();
        Person updatedPerson = personService.update(connection, person);
        return updatedPerson;
    }

    @PostMapping("/person/delete")
    public void delete(Person person){

        ConnectionManager.setConnection();
        Connection connection = ConnectionManager.connectionThread.get();
        person.setId(6);
        personService.delete(connection, person);
        ConnectionManager.manageTransaction(connection, true);
    }

}
