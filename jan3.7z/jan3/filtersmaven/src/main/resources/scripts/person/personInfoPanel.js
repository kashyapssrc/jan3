var personInfoPanel = {};
var personKeys = ['id', 'firstName', 'lastName', 'email', 'birth_date'];

personInfoPanel.createChildren = function() {}

personInfoPanel.createView = function() {
    personInfoPanel.view = service.doGet('html/personInfoPanel.html');
}

personInfoPanel.prePopulate = function() {}

personInfoPanel.listenEvents = function() {
    eventManager.subscribe('personSelected', onPersonSelect);
    eventManager.subscribe('personAdded', onPersonAdd);
    document.getElementById('submit').addEventListener('click', personSubmitted);
}

personInfoPanel.setDefault = function () {}

var onPersonAdd = function () {
    for(i = 0; i< personKeys.length; i++) {
        document.getElementById(personKeys[i]).value = '';
    }
    document.getElementById('id').disabled = true;
};

var personSubmitted = function () {
    var temp = {};
    var person = [];
    for(i = 0; i< personKeys.length; i++) {
        temp[personKeys[i]] = document.getElementById(personKeys[i]).value;
    }
    person.push(temp);
    eventManager.broadcast('personSubmitted', person);
};

var onPersonSelect = function(tableRow) {
    for(i = 0; i < personKeys.length; i++) {
        document.getElementById(personKeys[i]).value = tableRow.cells[i].innerHTML;
        var current = document.getElementsByClassName('active-row');
        if (current.length > 0) { 
            current[0].className = current[0].className.replace(' active-row', '');
        }
        tableRow.className += ' active-row';
    }
    document.getElementById('id').disabled = true
};