var personListPanel = {};
var isCreate;

personListPanel.createChildren = function() {}

personListPanel.createView = function() {
    personListPanel.view = service.doGet('html/personListPanel.jsp');
}

personListPanel.prePopulate = function() {
    var personList = service.doGet('http://localhost:8080/filter/do/person');
    personListPanel.person = personList;
}

personListPanel.listenEvents = function () {
    document.getElementById('table').addEventListener('click', personSelected);
    document.getElementById('add').addEventListener('click', personAdded);
    eventManager.subscribe('personSubmitted', onPersonSubmit);
}

personListPanel.setDefault = function () {
    eventManager.broadcast('personSelected', document.getElementById('table').rows[1]);
}

var personSelected = function () {
    eventManager.broadcast('personSelected', this);
    isCreate = false;
};

var personAdded = function () {
    eventManager.broadcast('personAdded', '');
    isCreate = true;
};

var onPersonSubmit = function (person) {
    if(isCreate === true) {
        personListPanel.person = service.doPut('http://localhost:8080/filter/do/person', person);
        personListPanel.createdPerson = [];
        personListPanel.createdPerson.push(personListPanel.person)
        personListPanel.constructTable(personListPanel.createdPerson);
        var lastRow = document.getElementById('table').rows.length;
        document.getElementById('table').rows[lastRow - 1].click();
    } else {
        personListPanel.person = service.doPost('http://localhost:8080/filter/do/person?op=update', person);
        personListPanel.updatedPerson = [];
        personListPanel.updatedPerson.push(personListPanel.person);
        personListPanel.updateTable(personListPanel.updatedPerson);
    }
};

personListPanel.updateTable = function(person) {

    var id = person[0].id;
    console.log(id);
    var rows = document.getElementById('table').rows;
    for(i = 1; i < rows.length; i++) {
        var entityId = rows[i].getElementsByTagName('td')[0].innerHTML;
        if(entityId === id) {
            for(j = 0; j < personKeys.length; j++) {
                var inputData = person[0][personKeys[j]];
                rows[i].cells[j].innerHTML = inputData;
            }
        }
    }
}
