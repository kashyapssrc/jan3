var personPanel = {};

personPanel.init = function() {
    personPanel.createChildren();
    personPanel.createView();
    personPanel.prePopulate();
    personPanel.listenEvents();
    personPanel.setDefault();
}

personPanel.createChildren = function() {
    personListPanel.createChildren();
    personInfoPanel.createChildren();
}

personPanel.createView = function() {

    personListPanel.createView();
    document.getElementById('person-panel').innerHTML = personListPanel.view;
    personInfoPanel.createView();
    document.getElementById('person-panel').innerHTML += personInfoPanel.view;
}

personPanel.prePopulate = function() {

    personListPanel.prePopulate();
    document.getElementById("table").innerHTML += personListPanel.person;
    personInfoPanel.prePopulate();
}

personPanel.listenEvents = function() {
    personListPanel.listenEvents();
    personInfoPanel.listenEvents();
}

personPanel.setDefault = function() {
    personListPanel.setDefault();
    personInfoPanel.setDefault();
}