var rsp = {};

rsp.createChildren = function() {}

rsp.createView = function() {
    rsp.View = service.doGet('html/rspView.jsp');
}

rsp.prePopulate = function() {};

rsp.listenEvents = function () {
    eventManager.subscribe('entitySelected', onSelectEntity);
}

rsp.setDefault = function() {}

var onSelectEntity = function(entity) {
    if(entity === 'person'){
        entityPerson();
        document.getElementById('rsp').innerHTML = rsp.personView;
        personPanel.init();
    } else if(entity === 'address'){
        entityAddress();
        document.getElementById('rsp').innerHTML = rsp.addressView;
        addressPanel.init();
    }
}

var entityAddress = function() {
    rsp.addressView = service.doGet('html/addressPanel.html');
}

var entityPerson = function() {
    rsp.personView = service.doGet('html/personPanel.html');
}