var service = {};
var response;
var createResponse;
var updateResponse;

service.doGet = function (url) {
    var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function () {

        if(httpRequest.readyState == 4 && httpRequest.status == 200) {
            response = httpRequest.responseText;
        }
    }
    httpRequest.open('GET', url, false);
    httpRequest.send();
    return response;
}

service.doPut = function (url, data) {
    var personObj = JSON.stringify(data[0]);
    var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function () {

        if(httpRequest.readyState == 4 && httpRequest.status == 200) {
            createResponse = JSON.parse(httpRequest.responseText);
        }
    }
    httpRequest.open('PUT', url, false);
    httpRequest.send(personObj);
    return createResponse;
}

service.doPost = function (url, data) {
    var updateObj = JSON.stringify(data[0]);
    console.log(updateObj);
    var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function () {

        if(httpRequest.readyState == 4 && httpRequest.status == 200) {
            updateResponse = JSON.parse(httpRequest.responseText);
        }
    }
    httpRequest.open('POST', url, false);
    httpRequest.send(updateObj);
    return updateResponse;
}