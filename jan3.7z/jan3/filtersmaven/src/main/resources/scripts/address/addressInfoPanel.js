var addressInfoPanel = {};
var addressKeys = ['id', 'street', 'city', 'postalcode'];

addressInfoPanel.createChildren = function() {}

addressInfoPanel.createView = function() {
    addressInfoPanel.view = service.doGet('html/addressInfoPanel.html');
}

addressInfoPanel.prePopulate = function() {}

addressInfoPanel.listenEvents = function() {
    eventManager.subscribe('addressSelected', onAddressSelect);
    eventManager.subscribe('addressAdded', onaddressAdd);
    document.getElementById('submit').addEventListener('click', submitSelected);
}

addressInfoPanel.setDefault = function () {}

var onaddressAdd = function () {
    for(i = 0; i< addressKeys.length; i++) {
        document.getElementById(addressKeys[i]).value = '';
    }
    document.getElementById('id').disabled = true;
};

var submitSelected = function () {
    var temp = {};
    var address = [];
    for(i = 0; i< addressKeys.length; i++) {
        temp[addressKeys[i]] = document.getElementById(addressKeys[i]).value;
    }
    address.push(temp);
    eventManager.broadcast('submitSelected', address);
};

var onAddressSelect = function(tableRow) {
    for(var j = 0; j < addressKeys.length; j++) {
        document.getElementById(addressKeys[j]).value = tableRow.cells[j].innerHTML;
        var current = document.getElementsByClassName('active-row');
        if (current.length > 0) { 
            current[0].className = current[0].className.replace(' active-row', '');
        }
        tableRow.className += ' active-row';
    }
    document.getElementById('id').disabled = true;
};