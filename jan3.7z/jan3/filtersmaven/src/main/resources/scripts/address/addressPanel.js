var addressPanel = {};

addressPanel.init = function() {
    addressPanel.createChildren();
    addressPanel.createView();
    addressPanel.prePopulate();
    addressPanel.listenEvents();
    addressPanel.setDefault();
}

addressPanel.createChildren = function() {
    addressListPanel.createChildren();
    addressInfoPanel.createChildren();
}

addressPanel.createView = function() {
    addressListPanel.createView();
    document.getElementById('address-panel').innerHTML += addressListPanel.view;
    addressInfoPanel.createView();
    document.getElementById('address-panel').innerHTML += addressInfoPanel.view;
}

addressPanel.prePopulate = function() {
    addressListPanel.prePopulate();
    addressInfoPanel.prePopulate();
}

addressPanel.listenEvents = function() {
    addressListPanel.listenEvents();
    addressInfoPanel.listenEvents();
}

addressPanel.setDefault = function() {
    addressListPanel.setDefault();
    addressInfoPanel.setDefault();
}