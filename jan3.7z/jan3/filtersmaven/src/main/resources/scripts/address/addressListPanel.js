var addressListPanel = {};

addressListPanel.createChildren = function() {}

addressListPanel.createView = function() {
    addressListPanel.view = service.doGet('html/addressListPanel.html');
}

addressListPanel.prePopulate = function() {
    var addressList = service.doGet('http://localhost:8080/filter/do/address?op=readAll');
    addressListPanel.address = JSON.parse(addressList);
    addressListPanel.constructTable(addressListPanel.address);
}

addressListPanel.listenEvents = function () {
    document.getElementById('table').addEventListener('click', addressSelected);
    document.getElementById('add').addEventListener('click', addressAdded);
    eventManager.subscribe('submitSelected', onSubmitSelect);
}

addressListPanel.setDefault = function () {
    eventManager.broadcast('addressSelected', document.getElementById('table').rows[1]);
}

var addressSelected = function () {
    eventManager.broadcast('addressSelected', this);
};

var addressAdded = function () {
    eventManager.broadcast('addressAdded', '');
};

var onSubmitSelect = function (address) {
    addressListPanel.constructTable(address);
};

addressListPanel.constructTable = function(address) {

    getaddressTable();
    var tempA = '';
    for(i = 0; i < address.length; i++) {

        var values = Object.values(address[i]);
        tempA += addressListPanel.addressTable.replace('%id%', values[0])
                                             .replace('%street%', values[1])
                                             .replace('%city%', values[2])
                                             .replace('%postalcode%', values[3])
    }
    document.getElementById('table').innerHTML += tempA;
}

var getaddressTable = function() {
    addressListPanel.addressTable = service.doGet('html/addressTable.html');
}