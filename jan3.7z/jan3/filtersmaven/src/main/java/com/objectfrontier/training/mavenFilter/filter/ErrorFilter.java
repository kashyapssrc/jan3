package com.objectfrontier.training.mavenFilter.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;

import com.objectfrontier.training.mavenFilter.util.AppException;
import com.objectfrontier.training.mavenFilter.util.JsonConverter;

public class ErrorFilter implements Filter{

    @Override
    public void destroy() { }

    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {


        log("\n%s", "error filter begins");
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        httpResponse.setContentType("application/json");
        PrintWriter out = httpResponse.getWriter();
        try {
            chain.doFilter(request, response);
            httpResponse.setStatus(HttpStatus.SC_OK);
        } catch (AppException e) {
            httpResponse.setStatus(HttpStatus.SC_INTERNAL_SERVER_ERROR);
            log("\n%s\nthis is the error",e.getErrorList());
            out.write(JsonConverter.toJson(e.getErrorList()));
        } catch (Exception e) {
            httpResponse.setStatus(HttpStatus.SC_INTERNAL_SERVER_ERROR);
            out.write(JsonConverter.toJson(e));
        }
        log("\n%s", "error filter ends");
    }

    @Override
    public void init(FilterConfig arg0) throws ServletException { }

    public static void log(String format, Object args) {
        System.out.format(format, args);
    }
}
