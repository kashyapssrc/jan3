package com.objectfrontier.training.mavenFilter.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.mavenFilter.model.Person;
import com.objectfrontier.training.mavenFilter.service.AuthenticationService;
import com.objectfrontier.training.mavenFilter.util.ConnectionManager;
import com.objectfrontier.training.mavenFilter.util.JsonConverter;

public class AuthenticationServlet extends HttpServlet{

    private static final long serialVersionUID = -3342585915025364636L;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        Connection connection = ConnectionManager.connectionThread.get();
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines()
                                       .collect(Collectors.toList());

        String personJson = String.join("", jsonLines);
        System.out.format("\nInput JSON >> %s", personJson);

        Person personCredentials = JsonConverter.toObject(personJson, Person.class);
        Person authenticatedPerson = new AuthenticationService().login(connection, personCredentials);
        out.write(JsonConverter.toJson(authenticatedPerson));
        HttpSession session = request.getSession();
        session.setAttribute("person", authenticatedPerson);
        Cookie cookie = new Cookie("JSESSIONID", session.getId());
        response.addCookie(cookie);
        response.setStatus(200);
        out.write("\nlogin successful");
    }

    @Override
    public void doDelete(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        session.invalidate();
        response.setStatus(200);
        out.write("\nlogout successful");
    }
}
