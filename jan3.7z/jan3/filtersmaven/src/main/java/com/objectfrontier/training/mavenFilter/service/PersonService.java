package com.objectfrontier.training.mavenFilter.service;

import static com.objectfrontier.training.mavenFilter.util.Statement.CREATE_PERSON;
import static com.objectfrontier.training.mavenFilter.util.Statement.DELETE_PERSON;
import static com.objectfrontier.training.mavenFilter.util.Statement.READ_ALL_PERSON;
import static com.objectfrontier.training.mavenFilter.util.Statement.READ_PERSON;
import static com.objectfrontier.training.mavenFilter.util.Statement.UPDATE_PERSON;
import static com.objectfrontier.training.mavenFilter.util.Statement.VALIDATE_AUTO_INCREMENT;
import static com.objectfrontier.training.mavenFilter.util.Statement.VALIDATE_DUPLICATE_EMAIL;
import static com.objectfrontier.training.mavenFilter.util.Statement.VALIDATE_DUPLICATE_NAME;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.objectfrontier.training.mavenFilter.model.Address;
import com.objectfrontier.training.mavenFilter.model.Person;
import com.objectfrontier.training.mavenFilter.util.AppException;
import com.objectfrontier.training.mavenFilter.util.ErrorCodes;

public class PersonService {

    private AddressService addressService;

    public PersonService(AddressService addressService) {
        super();
        this.addressService = addressService;
    }

    public PersonService() {
        super();
    }

    private void validateAutoIncrement(Connection connection) {

        try {
            String statement = VALIDATE_AUTO_INCREMENT;
            Statement validateStatement = connection.createStatement();
            ResultSet resultSet = validateStatement.executeQuery(statement);
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();

            if (resultSetMetaData.isAutoIncrement(1) == false ) {
                throw new AppException(ErrorCodes.AUTO_INC_FAIL);
            }
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }
    }

    private void isValidEmail (Connection connection,Person person) {

        try {
            String statement = VALIDATE_DUPLICATE_EMAIL;
            PreparedStatement validateStatement = connection.prepareStatement(statement);
            validateStatement.setString(1, person.getEmail());

            ResultSet resultSet = validateStatement.executeQuery();
            if (resultSet.next()) {
                throw new AppException(ErrorCodes.DUPLICATE_EMAIL);
            }
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }
    }

    private void isDuplicateName(Connection connection , Person person) {

        try {
            String statement = VALIDATE_DUPLICATE_NAME;
            PreparedStatement validateStatement = connection.prepareStatement(statement);
            validateStatement.setString(1, person.getFirstName());
            validateStatement.setString(2, person.getLastName());

            ResultSet resultSet = validateStatement.executeQuery();
            if(resultSet.next()) {
                throw new AppException(ErrorCodes.DUPLICATE_NAME);
            }
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }
    }

    private boolean isBlank(String param) {

        if (Objects.nonNull(param)) {
            return "".equals(param.trim());
        }
        return true;
    }

    private void isValid(Person person) {

        List<ErrorCodes> errorList = new ArrayList<>();

        if(isBlank(person.getFirstName()))  { errorList.add(ErrorCodes.FIRST_NAME_NULL); }
        if(isBlank(person.getLastName()))   { errorList.add(ErrorCodes.LAST_NAME_NULL); }
        if(isBlank(person.getBirth_date())) { errorList.add(ErrorCodes.DOB_NULL); }
        if(isBlank(person.getEmail()))      { errorList.add(ErrorCodes.MAIL_NULL); }
        if(!errorList.isEmpty()) {
            throw new AppException(errorList);
        }
    }

    private long validateBirthDate(Person person) {

        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
            dateFormat.setLenient(false);
            java.util.Date date = dateFormat.parse(person.getBirth_date());
            long birthDate = date.toInstant()
                                 .toEpochMilli();
            return birthDate;
        } catch (ParseException e) {
            throw new AppException(ErrorCodes.INVALID_ENTRY);
        }
    }

    private Address getAddress(Connection connection, ResultSet resultSet) {

        AddressService addressService = this.addressService;
        long addressId;
        try {
            addressId = resultSet.getLong("address_id");
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }
        Address address = addressService.read(connection, addressId);
        return address;
    }

    private Person constructPerson(ResultSet readResult) {

        Person person = new Person();
        try {
            person.setId(readResult.getLong("id"));
            person.setFirstName(readResult.getString("firstname"));
            person.setLastName(readResult.getString("lastname"));
            person.setEmail(readResult.getString("email"));
            person.setBirth_date(readResult.getString("birth_date"));
            person.setPassword(readResult.getString("password"));
            person.setAdmin(readResult.getBoolean("isAdmin"));
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }
        return person;

    }

    public Person create(Connection connection, Person person) {

        log("%s", "create person method begins");
        validateAutoIncrement(connection);
        isValid(person);
        isDuplicateName(connection, person);
        isValidEmail(connection, person);
        long birthDate = validateBirthDate(person);
        Timestamp createdDate = new Timestamp (System.currentTimeMillis());

        String statement = CREATE_PERSON;
        try {
            PreparedStatement createStatement = connection.prepareStatement(statement,
                    Statement.RETURN_GENERATED_KEYS);
            createStatement.setString(1, person.getFirstName());
            createStatement.setString(2, person.getLastName());
            createStatement.setString(3, person.getEmail());
            createStatement.setDate(4, new Date(birthDate));
            createStatement.setTimestamp(5, createdDate);
            createStatement.setString(6, person.getPassword());
            createStatement.setBoolean(7, person.isAdmin());
            createStatement.execute();

            ResultSet resultSet = createStatement.getGeneratedKeys();
            resultSet.next();
            person.setId(resultSet.getLong(1));
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }
        log("%s", "create person method ends");
        return person;
    }

    public Person update(Connection connection, Person person) {

        log("%s", "update person method begins");
        validateAutoIncrement(connection);
        isValid(person);
        isDuplicateName(connection, person);
        isValidEmail(connection, person);
        long birthDate = validateBirthDate(person);

        String statement = UPDATE_PERSON;
        try {
            PreparedStatement updateStatement = connection.prepareStatement(statement);
            updateStatement.setString(1, person.getFirstName());
            updateStatement.setString(2, person.getLastName());
            updateStatement.setString(3, person.getEmail());
            updateStatement.setDate(4, new Date (birthDate));
            updateStatement.setString(5, person.getPassword());
            updateStatement.setBoolean(6, person.isAdmin());
            updateStatement.setLong(7, person.getId());

            int rowsAffected = updateStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new AppException(ErrorCodes.ID_NOT_FOUND);
            }
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }

        log("%s", "update person method ends");
        return person;
    }

    public Person read(Connection connection, long personId, boolean includeAddress) {

        log("%s", "read person method begins");
        String statement = READ_PERSON;
        Person person = null;
        try {
            PreparedStatement readStatement = connection.prepareStatement(statement);
            readStatement.setLong(1, personId);

            ResultSet resultSet = readStatement.executeQuery();
            if(resultSet.next() ) {
                person = constructPerson(resultSet);
                if(includeAddress == true) {
                    Address address = getAddress(connection, resultSet);
                    person.setAddress(address);
                }
            } else {
                throw new AppException(ErrorCodes.ID_NOT_FOUND);
            }
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }

        log("%s", "read person method ends");
        return person;
    }

    public List<Person> readAll(Connection connection) {

        log("%s", "readAll person method begins");
        List<Person> personList = null;
        try {
            String statement = READ_ALL_PERSON;
            Statement readAllStatement = connection.createStatement();
            ResultSet resultSet = readAllStatement.executeQuery(statement);
            personList = new ArrayList<>();

            while(resultSet.next()) {
                Person person = constructPerson(resultSet);
                personList.add(person);
            }
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }

        log("%s", "readAll person method ends");
        return personList;
    }

    public void delete(Connection connection, Person person) {

        log("%s", "delete person method begins");
        try {
            String statement = DELETE_PERSON;
            PreparedStatement deleteStatement = connection.prepareStatement(statement);
            deleteStatement.setLong(1, person.getId());

            int rowsAffected = deleteStatement.executeUpdate();
            if(rowsAffected == 0) {
                throw new AppException(ErrorCodes.ID_NOT_FOUND);
            } else {
                AddressService addressService = this.addressService;
                addressService.delete(connection, person.getAddress()
                                                        .getId());
            }
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }
        log("%s", "delete person method ends");
    }

    public static void log(String format, Object args) {
        System.out.format(format, args);
    }

}

