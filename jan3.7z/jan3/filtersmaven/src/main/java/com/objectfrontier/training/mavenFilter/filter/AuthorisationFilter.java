package com.objectfrontier.training.mavenFilter.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.mavenFilter.model.Person;
import com.objectfrontier.training.mavenFilter.util.AppException;
import com.objectfrontier.training.mavenFilter.util.ErrorCodes;

public class AuthorisationFilter implements Filter{

    @Override
    public void destroy() { }

    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {

        log("\n%s","authorisation filter begins");
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpSession session = httpRequest.getSession(false);
        Person person = (Person) session.getAttribute("person");
        String operation = httpRequest.getParameter("op");
        String aid = httpRequest.getParameter("aid");
        boolean isDelete = false;

        if(operation != null) {
            isDelete = operation.equals("delete");
        } else if (aid != null ){
            isDelete = (aid !=null);
        }

        boolean allowedOperations = ("PUT".equals(httpRequest.getMethod()) ||
                                    ("POST".equals(httpRequest.getMethod()) &&
                                      isDelete));

        if(allowedOperations && (!person.isAdmin())) {
            throw new AppException(ErrorCodes.UNAUTHENTICATED_OPERATION);
        } else {
            chain.doFilter(request, response);
        }
        log("\n%s","authorisation filter ends");
    }

    @Override
    public void init(FilterConfig arg0) throws ServletException { }

    public static void log(String format, Object args) {
        System.out.format(format, args);
    }
}
