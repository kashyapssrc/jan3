package com.objectfrontier.training.mavenFilter.util;

import com.objectfrontier.training.mavenFilter.model.Address;
import com.objectfrontier.training.mavenFilter.model.Person;
import com.objectfrontier.training.mavenFilter.service.AddressService;
import com.objectfrontier.training.mavenFilter.service.PersonService;

public class ObjectManager {

    private static ConnectionManager connectionManager;
    private static Person person;
    private static Address address;
    private static PersonService personService;
    private static AddressService addressService;
    private static RequestHelper requestHelper;
    @SuppressWarnings("unused")
    private static ObjectManager objectFactory;

    static {
        objectFactory = new ObjectManager();
    }

    private ObjectManager() {

        super();
        connectionManager = new ConnectionManager();
        person = new Person();
        address = new Address();
        personService = new PersonService();
        addressService = new AddressService();
        requestHelper = new RequestHelper();
    }

    public static ConnectionManager getConnectionManager() {
        return connectionManager;
    }

    public static void setConnectionManager(ConnectionManager connectionManager) {
        ObjectManager.connectionManager = connectionManager;
    }

    public static Person getPerson() {
        return person;
    }

    public static void setPerson(Person person) {
        ObjectManager.person = person;
    }

    public static Address getAddress() {
        return address;
    }

    public static void setAddress(Address address) {
        ObjectManager.address = address;
    }

    public static PersonService getPersonService() {
        return personService;
    }

    public static void setPersonService(PersonService personService) {
        ObjectManager.personService = personService;
    }

    public static AddressService getAddressService() {
        return addressService;
    }

    public static void setAddressService(AddressService addressService) {
        ObjectManager.addressService = addressService;
    }

    public static RequestHelper getRequestHelper() {
        return requestHelper;
    }

    public static void setRequestHelper(RequestHelper requestHelper) {
        ObjectManager.requestHelper = requestHelper;
    }

    public static ObjectManager getObjectFactory() {
        return objectFactory;
    }

    public static void setObjectFactory(ObjectManager objectFactory) {
        ObjectManager.objectFactory = objectFactory;
    }


}
