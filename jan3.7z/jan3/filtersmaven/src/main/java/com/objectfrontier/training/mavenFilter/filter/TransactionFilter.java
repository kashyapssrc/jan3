package com.objectfrontier.training.mavenFilter.filter;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.objectfrontier.training.mavenFilter.util.ConnectionManager;

public class TransactionFilter implements Filter{

    boolean flag;
    @Override
    public void destroy() { }

    @Override
    public void doFilter(ServletRequest request,
                         ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {

        log("\n%s", "transaction filter begins");
        ConnectionManager.setConnection();
        Connection connection = ConnectionManager.connectionThread.get();

        try {
            chain.doFilter(request, response);
            flag = true;
        } catch (Exception e) {
            flag=false;
            throw e;
        } finally {
            ConnectionManager.manageTransaction(connection, flag);
            ConnectionManager.connectionThread.remove();
            log("\n%s", "transaction filter ends");
        }
    }

    @Override
    public void init(FilterConfig config) throws ServletException { }

    public static void log(String format, Object args) {
        System.out.format(format, args);
    }

}
