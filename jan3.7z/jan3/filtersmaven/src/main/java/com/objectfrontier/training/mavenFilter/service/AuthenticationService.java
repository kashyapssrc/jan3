package com.objectfrontier.training.mavenFilter.service;

import static com.objectfrontier.training.mavenFilter.util.Statement.VALIDATE_CREDENTIALS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.objectfrontier.training.mavenFilter.model.Person;
import com.objectfrontier.training.mavenFilter.util.AppException;
import com.objectfrontier.training.mavenFilter.util.ErrorCodes;

public class AuthenticationService {

    public Person login(Connection connection, Person person) {

        log("\n%s","login method begins");
        Person authenticatedPerson = new Person();
        try {

            PreparedStatement authenticateCredentials = connection.prepareStatement(VALIDATE_CREDENTIALS);
            authenticateCredentials.setString(1, person.getEmail());
            authenticateCredentials.setString(2, person.getPassword());

            ResultSet validUser = authenticateCredentials.executeQuery();
            if(validUser.next()) {

                authenticatedPerson.setEmail(validUser.getString("email"));
                authenticatedPerson.setPassword(validUser.getString("password"));
                authenticatedPerson.setAdmin(validUser.getBoolean("isAdmin"));
            } else {
                throw new AppException(ErrorCodes.INVALID_ENTRY);
            }
        } catch (SQLException e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }
        log("\n%s","login method ends");
        return authenticatedPerson;
    }

    public static void log(String format, Object args) {
        System.out.format(format, args);
    }
}
