package com.objectfrontier.training.mavenTest.test;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.mavenFilter.model.Address;
import com.objectfrontier.training.mavenFilter.util.AppException;
import com.objectfrontier.training.mavenFilter.util.ErrorCodes;
import com.objectfrontier.training.mavenFilter.util.HttpMethod;
import com.objectfrontier.training.mavenFilter.util.JsonConverter;
import com.objectfrontier.training.mavenFilter.util.RequestHelper;

public class TestAddressServlet extends TestBaseServlet {

    private static RequestHelper helper;

    @BeforeClass
    private void authenticate() {
        helper = super.login();
    }

    @AfterClass
    private void deAuthenticate() {
        super.logOut(helper);
    }

    @Test(dataProvider = "dpCreate", priority = 1, enabled = true)
    public void createTest(Address address, Object expectedResult) {

        try {
            Address created = helper.setSecured(true)
                                    .setMethod(HttpMethod.PUT)
                                    .setInput(address)
                                    .requestObject("/do/address", Address.class);

            Assert.assertEquals(JsonConverter.toJson(created), JsonConverter.toJson(expectedResult));

        } catch (Exception e) {
            if(e instanceof AppException) {
                Assert.assertEquals(((AppException) e).getErrorList(), expectedResult);
            }
        }
    }

    @DataProvider
    public Object[][] dpCreate() {

        Address address = new Address("Delhi street", "chennai", 800020);
        Address addressA = new Address("chennai street", "delhi", 901243);
        Address addressB = new Address("punjab street", "pondicherry", 801243);
        Address addressC = new Address("chennai street", "chennai", 800020);
        Address negAddress = new Address(null, null, 0);

        Address expectedAddress = new Address(2, "Delhi street", "chennai", 800020);
        Address expectedAddress2 = new Address(3, "chennai street", "delhi", 901243);
        Address expectedAddress3 = new Address(4, "punjab street", "pondicherry", 801243);
        Address expectedAddress4 = new Address(5, "chennai street", "chennai", 800020);

        List<ErrorCodes> expectedErrorList = new ArrayList<>();
        expectedErrorList.add(ErrorCodes.STREET_NULL);
        expectedErrorList.add(ErrorCodes.CITY_NULL);
        expectedErrorList.add(ErrorCodes.POSTAL_CODE_NULL);

        return new Object[][] {

            { address, expectedAddress},
            { addressA, expectedAddress2},
            { addressB, expectedAddress3},
            { addressC, expectedAddress4},
            { negAddress, expectedErrorList},

        };
    }

    @Test(dataProvider = "dpUpdate", priority = 2, enabled = true)
    public void updateTest(Address address, Object expectedResult) {

        try {
            Address updated = helper.setSecured(true)
                                    .setMethod(HttpMethod.POST)
                                    .setInput(address)
                                    .requestObject("/do/address", Address.class);

            Assert.assertEquals(JsonConverter.toJson(updated), JsonConverter.toJson(expectedResult));
        } catch (Exception e) {
            if(e instanceof AppException) {
                Assert.assertEquals(((AppException) e).getErrorList(), expectedResult);
            }
        }
    }

    @DataProvider
    public Object[][] dpUpdate() {

        Address address = new Address(2, "new delhi street", "coimbatore", 600020);
        Address negaddress = new Address(98, "dlehi street", "chi city", 5465231);
        Address negaddressB = new Address(1, null, null, 0);

        Address expectedAddress = new Address(2, "new delhi street", "coimbatore", 600020);

        List<ErrorCodes> expectedErrorList = new ArrayList<>();
        expectedErrorList.add(ErrorCodes.ID_NOT_FOUND);

        List<ErrorCodes> expectedErrorListB = new ArrayList<>();
        expectedErrorListB.add(ErrorCodes.STREET_NULL);
        expectedErrorListB.add(ErrorCodes.CITY_NULL);
        expectedErrorListB.add(ErrorCodes.POSTAL_CODE_NULL);

        return new Object[][] {

            { address, expectedAddress},
            { negaddress, expectedErrorList },
            { negaddressB, expectedErrorListB },
        };
    }

    @Test(dataProvider = "dpRead", priority = 3, enabled = true)
    public void readTest(long id, Object expectedResult) {

        try {
            Address actualAddress = helper.setSecured(true)
                                          .setMethod(HttpMethod.GET)
                                          .setInput(null)
                                          .requestObject("/do/address?id=" + id +
                                                         "&op=" + "read",
                                                         Address.class);
            System.out.println("this is the actual");
            System.out.println(actualAddress);
            Assert.assertEquals(JsonConverter.toJson(actualAddress), JsonConverter.toJson(expectedResult));
        } catch (Exception e) {
            if(e instanceof AppException) {
                System.out.println(((AppException) e).getErrorList());
                Assert.assertEquals(((AppException) e).getErrorList(), expectedResult);
            }
        }
    }

    @DataProvider
    public Object[][] dpRead() {

        long addressIdA = 1;
        long addressIdB = 0;

        Address expectedAddress = new Address(1, "del street", "chennai", 600030);

        List<ErrorCodes> expectedErrorList = new ArrayList<>();
        expectedErrorList.add(ErrorCodes.ID_NOT_FOUND);

        return new Object[][] {
            { addressIdA, expectedAddress},
            { addressIdB, expectedErrorList},
        };
    }

    @Test(dataProvider = "dpReadAll", priority = 4, enabled = true)
    public void readAllTest(List<Address> expectedAddress) {

        try {
            List<Address> actualAddress = helper.setSecured(true)
                                                .setMethod(HttpMethod.GET)
                                                .setInput(null)
                                                .requestList("/do/address?op=" + "readAll",
                                                             Address.class);

            Assert.assertEquals(JsonConverter.toJson(actualAddress), JsonConverter.toJson(expectedAddress));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @DataProvider
    public Object[][] dpReadAll() {

        Address expectedAddress = new Address(1, "del street", "chennai", 600030);
        Address expectedAddress1 = new Address(2, "new delhi street", "coimbatore", 600020);
        Address expectedAddress2 = new Address(3, "chennai street", "delhi", 901243);
        Address expectedAddress3 = new Address(4, "punjab street", "pondicherry", 801243);
        Address expectedAddress4 = new Address(5, "chennai street", "chennai", 800020);

        List<Address> expectedAddressList = new ArrayList<>();
        expectedAddressList.add(expectedAddress);
        expectedAddressList.add(expectedAddress1);
        expectedAddressList.add(expectedAddress2);
        expectedAddressList.add(expectedAddress3);
        expectedAddressList.add(expectedAddress4);


        return new Object[][] {
            { expectedAddressList}
        };
    }

    @Test(dataProvider = "dpSearch", priority = 5, enabled = true)
    public void searchTest(String[] fieldName,
                                    String searchText,
                                    Object expectedResult) {

        try {
            List<Address> actualAddress = helper.setSecured(true)
                                                .setMethod(HttpMethod.GET)
                                                .setInput(null)
                                                .requestList("/do/address?in=" + fieldName[0] +
                                                                        "&in=" + fieldName[1] +
                                                                        "&in=" + fieldName[2] +
                                                                        "&search=" + searchText +
                                                                        "&op=" + "search",
                                                             Address.class);

            Assert.assertEquals(JsonConverter.toJson(actualAddress),
                                JsonConverter.toJson(expectedResult));

        } catch (Exception e) {
            if (e instanceof AppException) {
                Assert.assertEquals(((AppException) e).getErrorList(), expectedResult);
            }
        }
    }

    @DataProvider
    public Object[][] dpSearch() {

        String[] fieldName = {"street", "city", "postalCode"};
        String[] fieldNameB = {" "};

        String searchText = "80";
        String searchTextB = null;

        Address expectedAddress3 = new Address(4, "punjab street", "pondicherry", 801243);
        Address expectedAddress4 = new Address(5, "chennai street", "chennai", 800020);

        List<Address> expectedAddressList = new ArrayList<>();
        expectedAddressList.add(expectedAddress3);
        expectedAddressList.add(expectedAddress4);

        List<ErrorCodes> expectedErrorList = new ArrayList<>();
        expectedErrorList.add(ErrorCodes.FIELD_NULL);
        expectedErrorList.add(ErrorCodes.SEARCH_TEXT_EMPTY);

        return new Object[][] {

            { fieldName, searchText, expectedAddressList},
            { fieldNameB, searchTextB, expectedErrorList},

        };
    }

    @Test(dataProvider = "dpDelete", priority = 6, enabled = true)
    public void deleteTest(long id , List<ErrorCodes> expectedErrorList) {

        try {
            helper.setSecured(true)
                  .setMethod(HttpMethod.POST)
                  .requestObject("/do/address?aid=" + id, Address.class);

        } catch (Exception e) {
            if(e instanceof AppException) {
                Assert.assertEquals(((AppException) e).getErrorList(), expectedErrorList);
            }
        }
    }

    @DataProvider
    public Object[][] dpDelete() {

        long id = 2;
        long addressId = 2;

        List<ErrorCodes> expectedErrorList = new ArrayList<>();
        expectedErrorList.add(ErrorCodes.ID_NOT_FOUND);

        return new Object[][] {

            { id, null},
            { addressId, expectedErrorList},
        };
    }
}
