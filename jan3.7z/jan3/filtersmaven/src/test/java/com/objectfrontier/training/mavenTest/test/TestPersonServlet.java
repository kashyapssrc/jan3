package com.objectfrontier.training.mavenTest.test;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.mavenFilter.model.Address;
import com.objectfrontier.training.mavenFilter.model.Person;
import com.objectfrontier.training.mavenFilter.util.AppException;
import com.objectfrontier.training.mavenFilter.util.ErrorCodes;
import com.objectfrontier.training.mavenFilter.util.HttpMethod;
import com.objectfrontier.training.mavenFilter.util.JsonConverter;
import com.objectfrontier.training.mavenFilter.util.RequestHelper;

public class TestPersonServlet extends TestBaseServlet {

    private static RequestHelper helper;

    @BeforeClass
    private void authenticate() {
        helper = super.login();
    }

    @AfterClass
    private void deAuthenticate() {
        super.logOut(helper);
    }

    @Test(dataProvider = "dpCreate", priority = 1, enabled = true)
    public void createTest(Person input, Object expectedResult) {

        try {
            Person created = helper.setSecured(true)
                                   .setMethod(HttpMethod.PUT)
                                   .setInput(input)
                                   .requestObject("/do/person", Person.class);

            Assert.assertEquals(JsonConverter.toJson(created), JsonConverter.toJson(expectedResult));

        } catch (Exception e) {
            if(e instanceof AppException) {
                Assert.assertEquals(((AppException) e).getErrorList(), expectedResult);
            }
        }
    }

    @DataProvider
    public Object[][] dpCreate() {

        Address address = new Address("delhi street", "chennai", 600030);
        Address expectedAddress = new Address(2, "delhi street", "chennai", 600030);

        Person person = new Person("abhi", "shek", "abhi@sheka.com", "09-09-1997", "yolo", true, address);
        Person person2 = new Person(null, null, null, null, null, true, address);

        Person expectedPerson = new Person(2,
                                           "abhi",
                                           "shek",
                                           "abhi@sheka.com",
                                           "09-09-1997",
                                           "yolo",
                                           true,
                                           expectedAddress);

        List<ErrorCodes> expectedErrorList = new ArrayList<>();
        expectedErrorList.add(ErrorCodes.FIRST_NAME_NULL);
        expectedErrorList.add(ErrorCodes.LAST_NAME_NULL);
        expectedErrorList.add(ErrorCodes.DOB_NULL);
        expectedErrorList.add(ErrorCodes.MAIL_NULL);
        expectedErrorList.add(ErrorCodes.PASSWORD_NULL);


        return new Object[][] {
            { person, expectedPerson},
            { person2, expectedErrorList}
        };
    }

    @Test(dataProvider = "dpUpdate", priority = 2, enabled = true)
    public void updateTest(Person input, Object expectedResult) {

        try {
            Person update = helper.setSecured(true)
                                  .setMethod(HttpMethod.POST)
                                  .setInput(input)
                                  .requestObject("/do/person?op=" + "update", Person.class);

            Assert.assertEquals(JsonConverter.toJson(update), JsonConverter.toJson(expectedResult));

        } catch (Exception e) {
            if(e instanceof AppException) {
                Assert.assertEquals(((AppException) e).getErrorList(), expectedResult);
            }
        }
    }

    @DataProvider
    public Object[][] dpUpdate() {

        Address address = new Address(2,"delhi street", "chennai", 600030);
        Address expectedAddress = new Address(2, "delhi street", "chennai", 600030);

        Person person = new Person(2,
                                   "abhida",
                                   "shekda",
                                   "abhi@shekada.com",
                                   "09-09-1997",
                                   "yes",
                                   true,
                                   address);

        Person person2 = new Person(2, null, null, null, null, null, true, address);

        Person expectedPerson = new Person(2,
                                           "abhida",
                                           "shekda",
                                           "abhi@shekada.com",
                                           "09-09-1997",
                                           "yes",
                                           true,
                                           expectedAddress);

        List<ErrorCodes> expectedErrorList = new ArrayList<>();
        expectedErrorList.add(ErrorCodes.FIRST_NAME_NULL);
        expectedErrorList.add(ErrorCodes.LAST_NAME_NULL);
        expectedErrorList.add(ErrorCodes.DOB_NULL);
        expectedErrorList.add(ErrorCodes.MAIL_NULL);
        expectedErrorList.add(ErrorCodes.PASSWORD_NULL);


        return new Object[][] {
            { person, expectedPerson},
            { person2, expectedErrorList},
        };
    }

    @Test(dataProvider = "dpRead", priority = 3, enabled = true)
    public void readTest(long id ,
                         boolean includeAddress,
                         Object expectedResult) {

        try {
            Person actualPerson = helper.setSecured(true)
                                        .setMethod(HttpMethod.GET)
                                        .setInput(null)
                                        .requestObject("/do/person?id=" + id +
                                                       "&addr=" + includeAddress,
                                                       Person.class);

            Assert.assertEquals(JsonConverter.toJson(actualPerson), JsonConverter.toJson(expectedResult));
        } catch (Exception e) {
            if(e instanceof AppException) {
                Assert.assertEquals(((AppException) e).getErrorList(), expectedResult);
            }
        }
    }

    @DataProvider
    public Object[][] dpRead() {

        long id = 2;
        boolean includeAddress = true;

        Address expectedAddress = new Address(2, "delhi street", "chennai", 600030);
        Person expectedPerson = new Person(2,
                                           "abhida",
                                           "shekda",
                                           "abhi@shekada.com",
                                           "1997-09-09",
                                           "yes",
                                           true,
                                           expectedAddress);

        long personId = 0;
        List<ErrorCodes> expectedErrorList = new ArrayList<>();
        expectedErrorList.add(ErrorCodes.ID_NOT_FOUND);

        return new Object[][] {
            { id, includeAddress, expectedPerson},
            { personId, includeAddress, expectedErrorList},
        };
    }

    @Test(dataProvider = "dpReadAll", priority = 4, enabled = true)
    public void readAllTest(List<Person> expectedPerson) {

        try {
            List<Person> actualPerson = helper.setSecured(true)
                                              .setMethod(HttpMethod.GET)
                                              .setInput(null)
                                              .requestList("/do/person", Person.class);

            Assert.assertEquals(JsonConverter.toJson(actualPerson), JsonConverter.toJson(expectedPerson));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @DataProvider
    public Object[][] dpReadAll() {

        Address expectedAddress = new Address(1, "del street", "chennai", 600030);
        Address expectedAddressA = new Address(2, "delhi street", "chennai", 600030);
        Person expectedPerson = new Person(1,
                                           "ola",
                                           "uber",
                                           "abhi@him.com",
                                           "2018-11-28",
                                           "yolo",
                                           true,
                                           expectedAddress);
        Person expectedPersonA = new Person(2,
                                           "abhida",
                                           "shekda",
                                           "abhi@shekada.com",
                                           "1997-09-09",
                                           "yes",
                                           true,
                                           expectedAddressA);

        List<Person> expectedPersonList = new ArrayList<>();
        expectedPersonList.add(expectedPerson);
        expectedPersonList.add(expectedPersonA);

        return new Object[][] {
            { expectedPersonList}
        };
    }

    @Test(dataProvider = "dpDelete", priority = 5, enabled = true)
    public void deleteTest(Person person, List<ErrorCodes> expectedErrorList) {

        try {
            helper.setSecured(true)
                  .setMethod(HttpMethod.POST)
                  .setInput(person)
                  .requestObject("/do/person?op=" + "delete", Person.class);

        } catch (Exception e) {
            if(e instanceof AppException) {
                Assert.assertEquals(((AppException) e).getErrorList(), expectedErrorList);
            }
        }
    }

    @DataProvider
    public Object[][] dpDelete() {

        Address address = new Address();
        address.setId(2);
        Person person = new Person();
        person.setId(2);
        person.setAddress(address);

        Address address2 = new Address();
        address2.setId(98);
        Person person2 = new Person();
        person2.setId(98);
        person2.setAddress(address2);

        List<ErrorCodes> expectedErrorList = new ArrayList<>();
        expectedErrorList.add(ErrorCodes.ID_NOT_FOUND);

        return new Object[][] {
            { person, null},
            { person2, expectedErrorList},
        };
    }
}
