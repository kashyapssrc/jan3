package com.objectfrontier.training.mavenTest.test;

import java.net.URI;
import java.net.URL;

import org.apache.http.HttpResponse;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.util.resource.Resource;
import org.eclipse.jetty.webapp.WebAppContext;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.objectfrontier.training.mavenFilter.model.Person;
import com.objectfrontier.training.mavenFilter.util.AppException;
import com.objectfrontier.training.mavenFilter.util.ErrorCodes;
import com.objectfrontier.training.mavenFilter.util.HttpMethod;
import com.objectfrontier.training.mavenFilter.util.RequestHelper;

public class TestBaseServlet {

    Person person = new Person(null, null, "abhi@him.com", null, "yolo", false, null);
    // initialize your person with credentials

    protected RequestHelper login() {
        return login(person);
    }

    protected RequestHelper login(Person person) {

        try {

            RequestHelper helper = RequestHelper.create();
            // Prepare your login call here, if you have implemented it in a
            // different HTTP Method
            HttpResponse response = helper.setMethod(HttpMethod.POST)
                                          .setInput(person)
                                          .requestRaw("/login");

            log(RequestHelper.asString(response));
            Assert.assertEquals(RequestHelper.getStatus(response), 200);
            helper.setSecureDetails(response);
            return helper;
        } catch (Exception e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }
    }

    protected void logOut(RequestHelper helper) {

        try {
            HttpResponse response = helper.setMethod(HttpMethod.DELETE)
                                          .setInput(null)
                                          .requestRaw("/logout");

            log(RequestHelper.asString(response));
            Assert.assertEquals(RequestHelper.getStatus(response), 200);
        } catch (Exception e) {
            throw new AppException(ErrorCodes.SERVER_ERROR);
        }
    }

    private static Server server;
    private static int port = 8080;
    private static String contextPath = "/filter";

    @BeforeSuite
    protected void initServer() throws Exception {

        server = new Server(port);

        URL webXmlResource = server.getClass()
                                   .getClassLoader()
                                   .getResource("web.xml");

        URI webResourceBase = webXmlResource.toURI()
                                            .resolve("..")
                                            .normalize();

        log("Using BaseResource: " + webResourceBase);
        WebAppContext context = new WebAppContext();
        context.setBaseResource(Resource.newResource(webResourceBase));
        context.setContextPath(contextPath);
        context.setParentLoaderPriority(true);
        server.setHandler(context);
        server.start();

        String baseUrl = String.format("http://localhost:%s%s", port, contextPath);
        RequestHelper.setBaseUrl(baseUrl);
    }

    @AfterSuite
    protected void stopServer() throws Exception {
        server.stop();
    }

    void log(String message) {
        System.out.println(message);
    }
}
